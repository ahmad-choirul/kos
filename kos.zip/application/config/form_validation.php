<?php
/*
/--------------------------------------------------------------------------
/ Config error message on form validation
/--------------------------------------------------------------------------
*/
$config['error_prefix'] = '<div class="text-danger">';
$config['error_suffix'] = '</div>';
?>
