</div><!-- /.content-wrapper -->

<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>Version</b> 2.0
	</div>
	<strong>Developed By: Kelompok PKL ILKOM UNEJ </strong>
</footer>
</div><!-- ./wrapper -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
</body>
</html>