<section class="content-header">
selamat datang <?php echo $this->session->userdata('nama') ?>
</section>

<!-- Main content -->
<section class="content">

</section><!-- /.content -->